 
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container">
    <?php
    $today = Carbon\Carbon::now();
    
    ?>  
  <span class="label label-primary center-block"> <?php echo e(date('h:i A')); ?> </span>
    

  <h1 class="my-4 alert-success">Welcome To RYDOBD.com
      <span class="pull-right"><?php echo e($today->day.' '.$today->format('F').' '.$today->year); ?></span>
  </h1>
  
  <!-- Marketing Icons Section -->
  
  <!-- /.row -->

  <!-- Portfolio Section -->
  

  
  <!-- /.row -->

  <!-- Features Section -->
  <div class="row">
    <div class="col-lg-6">
      <h2><?php echo e($post->post_title); ?></h2>
      
      <p><?php echo e($post->post_description); ?></p>
    </div>
    <div class="col-lg-6">
      <img class="img-fluid rounded" src=" <?php echo e(asset('images').'/'.$post->image); ?> " alt="">
    </div>
  </div>
  <!-- /.row -->

  <hr>

  <!-- Call to Action Section -->
  

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>