<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<header>
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('img/Pic1.jpg')">
        <div class="carousel-caption d-none d-md-block">
          
        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/Pic2.jpg')">
        <div class="carousel-caption d-none d-md-block">
          
        </div>
      </div>
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/Pic3.jpg')">
        <div class="carousel-caption d-none d-md-block">
          
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</header>
<!-- Page Content -->
<div class="container">
    <?php
    $today = Carbon\Carbon::now();

    ?>
  <span class="label label-primary center-block"> <?php echo e(date('h:i A')); ?> </span>


  <h1 class="my-4 alert-success">Welcome To RYDOBD.com
      <span class="pull-right"><?php echo e($today->day.' '.$today->format('F').' '.$today->year); ?></span>
  </h1>
  
  <h2>Events</h2>

  <div class="row">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="<?php echo e(route('viewPost', $post->id)); ?>" ><img class="card-img-top" src=" <?php echo e(asset('images').'/'.$post->image); ?> " alt="no image found" style="width: 350px; height: 200px;"></a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="<?php echo e(route('viewPost', $post->id)); ?>" style="text-decoration:none;"><?php echo e($post->post_title); ?></a>
              <br><?php echo e($post->created_at->toDateString()); ?>

            </h4>
            <?php echo e(str_limit($post->post_description, 100)); ?>

          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <div class="d-flex justify-content-center">
      <?php echo e($posts->links()); ?>

  </div>

  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>