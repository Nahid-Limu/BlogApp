<?php $__env->startSection('content'); ?>

<div class="jumbotron">
        <?php if(Session::has('message')): ?>
        <div id="successMessage" class="alert alert-dismissible alert-success" style="display: inline-block; float: right; ">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong> <?php echo e(Session::get('message')); ?> </strong>
        </div>
        <?php endif; ?>

    <h1 class="">Add New Posts</h1>
    <form action=" <?php echo e(route('addPost')); ?> " method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <table class="table table-bordered">
    <tr>
            <td>
                <label for="postTitle">Post Title:</label>
            </td>
            <td>
                <input class="form-control" type="text" name="postTitle" id="postTitle" required>
            </td>
        </tr>
        <tr>
            <td>
                <label for="postDescription">Post Description:</label>
            </td>
            <td>
                <textarea cols="110" rows="10" type="text" name="postDescription" id="postDescription"></textarea>
            </td>
        </tr>
        <tr>
            <td>
                <label for="image">Upload Image:</label>
            </td>
            <td>
                <input class="form-control" type="file" name="image" id="image">
            </td>
        </tr>

    </table>
    <button class="btn btn-info offset-6" type="submit">Add Post</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
            //text eiditior
            //tinymce.init({selector: 'textarea'});

            //flash msg
            $("#successMessage").fadeTo(1000, 500).slideUp(500, function(){
                $("#successMessage").alert('close');
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>