<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\Post;
use App\ImageUpload;


class AdminController extends Controller
{
  public function login()
  {
    return view('admin.login');
  }
    public function viewDashboard()
    {
        return view('admin.dashboard');
    }

    public function viewPost()
    {
        return view('admin.post');
    }

    

    public function imageGallery()
    {
        return view('admin.imageGallery');
    }

    public function addPost(Request $request)
    {
       //return $request->all();
       $post = new Post;

       $postTitle = $request->postTitle;
       $postDescription = $request->postDescription;

       //$imageName = time().'.'.request()->image->getClientOriginalExtension();
       $imageName = time().'-'.request()->image->getClientOriginalName();
       request()->image->move(public_path('images'), $imageName);
       //echo $imageName;

       $post->post_title = $postTitle;
       $post->post_description = $postDescription;
       $post->image = $imageName;

       $post->save();

       return back()->with('message','Post Add successfully.');



    }

    public function fileStore(Request $request)
    {
        $image = $request->file('file');
        $imageName = $image->getClientOriginalName();
        $image->move(public_path('images'),$imageName);
        
        $imageUpload = new ImageUpload();
        $imageUpload->image = $imageName;
        $imageUpload->save();
        return response()->json(['success'=>$imageName]);
    }
    public function fileDestroy(Request $request)
    {
        $filename =  $request->get('filename');
        ImageUpload::where('image',$filename)->delete();
        $path=public_path().'/images/'.$filename;
        if (file_exists($path)) {
            unlink($path);
        }
        return $filename;  
    }
}
