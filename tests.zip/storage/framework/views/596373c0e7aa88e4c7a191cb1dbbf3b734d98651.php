<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="/" style="font-family: Curlz MT; font-size: 30px; color: red;">
        <img class="card-img-top" src=" <?php echo e(asset('img').'/'.'logo.png'); ?> " alt="no image found" style="width: 70px; height:70px;">
      </a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="about.html">UpComming Event</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="services.html">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.html">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.html">About</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>

  